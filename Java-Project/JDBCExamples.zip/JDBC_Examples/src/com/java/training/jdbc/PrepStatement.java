package com.java.training.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class PrepStatement {

	// JDBC driver name and database URL
	static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
	static final String DB_URL = "jdbc:mysql://localhost:3306/training";
	// Database credentials
	static final String USER = "root";
	static final String PASS = "admin";
	
	public static void main(String[] args) {
		Connection conn = null;
		PreparedStatement preparedStatement = null;
		
		try{
			//STEP 2: Register JDBC driver
			Class.forName(JDBC_DRIVER);
			conn = DriverManager.getConnection(DB_URL,USER,PASS);

			
			// Update Employee Record
			String sql = "update student set firstname=? , lastname=? where id=?";

			 preparedStatement = conn.prepareStatement(sql);

			preparedStatement.setString(1, "Gary");
			preparedStatement.setString(2, "Larson");
			preparedStatement.setLong  (3, 100);

			int rowsAffected = preparedStatement.executeUpdate();
			
			System.out.println("Update Query Execution Status :" + rowsAffected);
			
			//Verifying if Employee has been Updated successfully
			 sql = "select * from student where id=?";

			 preparedStatement = conn.prepareStatement(sql);

			preparedStatement.setInt(1, 100);

			ResultSet rs = preparedStatement.executeQuery();
			while(rs.next()){
				//Retrieve by column name
				int id = rs.getInt("id");
				String first = rs.getString("firstname");
				String last = rs.getString("lastname");
				//Display values
				System.out.print("ID: " + id);
				System.out.print(", First: " + first);
				System.out.println(", Last: " + last);	
			}

			
			//STEP 6: Clean-up environment
			preparedStatement.close();
			conn.close();
		}catch(SQLException se){
			//Handle errors for JDBC
			se.printStackTrace();
		}catch(Exception e){
			//Handle errors for Class.forName
			e.printStackTrace();
		}finally{
		//finally block used to close resources
			try{
				if(preparedStatement!=null)
					preparedStatement.close();
			}catch(SQLException se2){
				
			}// nothing can be done
			
			try{
				if(conn!=null)
					conn.close();
			}catch(SQLException se){
				se.printStackTrace();
			}//end finally try
		}//end try
		System.out.println("Goodbye!");
	}//end main

}
