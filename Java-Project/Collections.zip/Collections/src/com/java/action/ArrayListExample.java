package com.java.action;

import java.util.ArrayList;
import java.util.Iterator;

public class ArrayListExample {
	
	public static void main(String[] args) {
//		ArrayList arrList = new ArrayList(); //Non-Generic way of Declaration
		
		ArrayList<String> arrList = new ArrayList<String>(); //Generic way of declaration
		arrList.add("Mango");
		arrList.add("Papaya");
		arrList.add("Guava");
		arrList.add("Cherry");
		arrList.add("Banana");
		arrList.add("orange");
		arrList.add("Mango");
//		arrList.add(12);
		
		Employee emp = new Employee();
//		arrList.add(emp);

		Iterator itr = arrList.iterator();
		while(itr.hasNext()) {
			System.out.println(itr.next());
		}
		
	}
}
