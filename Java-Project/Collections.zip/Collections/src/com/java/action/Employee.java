package com.java.action;

public class Employee {
	int empID;
	String empName;
	float empSal;
	
	public Employee() {
		
	}
	
}
