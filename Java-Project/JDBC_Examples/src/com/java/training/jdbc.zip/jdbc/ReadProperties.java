package com.java.training.jdbc;

public class ReadProperties {

}
