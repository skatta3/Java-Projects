package com.struts;

public class Welcome {
public String execute(){
	return "success";
}
}
